import React from 'react'

function App() {
  return <h1>Welcome to LynqBot: Content to Conversion</h1>
}

export default App